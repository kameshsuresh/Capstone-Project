import React from "react";

export default function HomePage() {
  return (
    <div>
      <h1>Crypto Capstone App</h1>
      <p>Use the navigation above to view Watchlist and Notes.</p>
    </div>
  );
}
