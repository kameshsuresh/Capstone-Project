export const getUsers = async (req, res) => {
    res.json({message: "Users route is working"});
};